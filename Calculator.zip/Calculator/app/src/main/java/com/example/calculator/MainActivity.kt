package com.example.calculator

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ed1 = findViewById<EditText>(R.id.editt1)
        val ed2 = findViewById<EditText>(R.id.editt2)
        val add = findViewById<Button>(R.id.btnAdd)
        val sub = findViewById<Button>(R.id.btnSub)
        val mul = findViewById<Button>(R.id.btnMul)
        val div = findViewById<Button>(R.id.btnDiv)

        // for addition
        add.setOnClickListener {

            if (ed1.text.toString() != " " && ed2.text.toString()!=" ")
            {
                val no1 = ed1.text.toString().toInt()
                val no2 = ed2.text.toString().toInt()

                val sum = no1 + no2

                Toast.makeText(this, "Addition: $sum", Toast.LENGTH_LONG).show()
            }
            else
                Toast.makeText(this, "Please fill the all blank", Toast.LENGTH_LONG).show()
        }

        // subtraction
        sub.setOnClickListener {

            if (ed1.text.toString() != " " && ed2.text.toString()!=" ")
            {
                val no1 = ed1.text.toString().toInt()
                val no2 = ed2.text.toString().toInt()

                val Sub : Int

                Sub = if (no1>no2){
                    no1 - no2
                }
                else{
                    no2-no1
                }

                Toast.makeText(this, "Subtraction: $Sub", Toast.LENGTH_LONG).show()
            }
            else
                Toast.makeText(this, "Please fill the all blank", Toast.LENGTH_LONG).show()
        }

        // Multiplication
        mul.setOnClickListener {

            if (ed1.text.toString() != " " && ed2.text.toString()!=" ")
            {
                val no1 = ed1.text.toString().toInt()
                val no2 = ed2.text.toString().toInt()

                val mul = no1 * no2

                Toast.makeText(this, "Multiplication: $mul", Toast.LENGTH_LONG).show()
            }
            else
                Toast.makeText(this, "Please fill the all blank", Toast.LENGTH_LONG).show()
        }

        // division
        div.setOnClickListener {

            if (ed1.text.toString() != " " && ed2.text.toString()!=" ")
            {
                val no1 = ed1.text.toString().toInt()
                val no2 = ed2.text.toString().toInt()

                val div : Double
                if (no2 == 0){
                    div = 0.0
                    Toast.makeText(this, "You can't declare no2 as a 0 : $div", Toast.LENGTH_LONG).show()
                }
                else{
                    div = (no1/no2).toDouble()
                    Toast.makeText(this, "Division: $div", Toast.LENGTH_LONG).show()
                }
            }
            else
                Toast.makeText(this, "Please fill the all blank", Toast.LENGTH_LONG).show()
        }
    }
}